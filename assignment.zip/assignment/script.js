// Task 2:
// Calculate total sum and average of numbers
function calculateSumAndAverage(numbers) {
    if (!Array.isArray(numbers) || numbers.length === 0) {
        return { sum: 0, average: 0 };
    }

    const sum = numbers.reduce((acc, num) => acc + num, 0);
    const average = sum / numbers.length;
    return { sum, average };
}

// Example usage
const numbers = [10, 20, 30, 40, 50];
console.log("Sum and Average:", calculateSumAndAverage(numbers));

// Task 3:
// Remove duplicates from an array of strings
function removeDuplicates(strings) {
    return Array.from(new Set(strings));
}

// Example usage
const strings = ["apple", "banana", "apple", "orange", "banana", "grape"];
console.log("Unique Strings:", removeDuplicates(strings));
