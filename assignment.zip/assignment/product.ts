// Task 4:
// Interface for Product and total price calculation
export interface Product {
    name: string;
    price: number;
}

// Function to calculate total price of products
export function calculateTotalPrice(products: Product[]): number {
    return products.reduce((total, product) => total + product.price, 0);
}

// Example usage of Task 4
const products: Product[] = [
    { name: "Apple", price: 1.2 },
    { name: "Banana", price: 0.8 },
    { name: "Orange", price: 1.5 },
];
console.log("Total Price:", calculateTotalPrice(products));

// Task 5:
// Function to validate an email address
export function isValidEmail(email: string): boolean {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
}

// Example usage of Task 5
const testEmail = "example@domain.com";
console.log(`Is "${testEmail}" a valid email?`, isValidEmail(testEmail));
