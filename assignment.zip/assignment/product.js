"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.calculateTotalPrice = calculateTotalPrice;
exports.isValidEmail = isValidEmail;
// Function to calculate total price of products
function calculateTotalPrice(products) {
    return products.reduce(function (total, product) { return total + product.price; }, 0);
}
// Example usage of Task 4
var products = [
    { name: "Apple", price: 1.2 },
    { name: "Banana", price: 0.8 },
    { name: "Orange", price: 1.5 },
];
console.log("Total Price:", calculateTotalPrice(products));
// Task 5:
// Function to validate an email address
function isValidEmail(email) {
    var emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
}
// Example usage of Task 5
var testEmail = "example@domain.com";
console.log("Is \"".concat(testEmail, "\" a valid email?"), isValidEmail(testEmail));
